package com.project.beans;

public enum RoleName 
{
	ADMIN,
	USER,
	MANAGER,
	DISTR_SUPERVISOR;
	
}
