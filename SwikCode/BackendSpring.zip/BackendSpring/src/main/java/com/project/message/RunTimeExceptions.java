package com.project.message;

public class RunTimeExceptions extends RuntimeException{

	public RunTimeExceptions(String message) {
		super(message);
	}
}
