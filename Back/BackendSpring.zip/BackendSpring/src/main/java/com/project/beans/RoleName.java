package com.project.beans;

public enum RoleName 
{
	ADMIN,
	USER,
	DOCTOR,
	FOSTER;
	
}
