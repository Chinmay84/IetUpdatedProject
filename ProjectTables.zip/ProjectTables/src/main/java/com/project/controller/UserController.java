package com.project.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.bean.User;

@RestController
public class UserController {
//
//	@GetMapping(value="/register",produces="application/json")
//	public String forAddUser()
//	{
//
//		return "on register page";
//	}
//
//	
//	@PostMapping(value="/register",produces="application/json",consumes="application/json")
//	public String forAddUser(@RequestBody User user)
//	{
//		if(userService.addUser(user)>0) {
//			return "register successfull";
//		}
//		return "register not successful";
//	}
	
	
	
	
	
}
