import React from 'react'
import {showPosts} from './showPosts';

function Posts() {
    return (
        <div className="posts">
            <showPosts/>
        </div>
    )
}

export default Posts
